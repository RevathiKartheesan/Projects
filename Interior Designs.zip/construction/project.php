	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="codepixer">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>projects</title>
		<style>
		img{
			width:370px;
			height:370px;
		}
		#im{
			height:15%;
			width:15%;
		}
</style>
<style>
.container {
  position: relative;
  width: 50%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.3;
}

.container:hover .middle {
  opacity: 1;
}

.text {
  background-color: LightCoral;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
}
</style>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">	
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>

<?php
							
							
							session_start();
							$name=$_SESSION['name'];
      ?>
			  <header id="header" id="home">
			    <div class="container">
			    	<div class="row header-top align-items-center">
			    		<div class="col-lg-4 col-sm-4 menu-top-left">
			    			<img id="im" src="pic/l2.jpg"></img>
			    			<a class="tel" href="mailto:smartlooklet@gmail.com">smartlooklet@gmail.com</a>
			    		</div>
			    		<div class="col-lg-4 menu-top-middle justify-content-center d-flex">
							<a href="index.html">
								<h1>SMART LOOKLET</h1>	
							</a>			    			
			    		</div>
			    		<div class="col-lg-4 col-sm-4 menu-top-right">
			    			<a class="tel" href="tel:+777 000 22299">+777 000 22299</a>
			    			<img id="im" src="pic/l1.jpg"></img>
							<h1 style="color:red;font-size:20px;"><?=$name?></h1>
			    		</div>
			    	</div>			    </div>	
			    	<hr>
			    <div class="container">	
			    	<div class="row align-items-center justify-content-center d-flex">
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li><a href="index.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
						  <li class="menu-active"><a href="project.php">Project</a></li>
						  <li><a href="cart.php">Order</a></li>
				          <li><a href="contact.php">Contact</a></li>
						  <li><a href="admin.php">Admin</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Our Projects	
							</h1>	
							
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start price Area -->
			<section class="price-area section-gap">
		
				<div id="portfolio">
  <div class="container">
    <div class="section-title">
      <h2>Our Works</h2>
    </div>
    <div class="row">
      <div class="portfolio-items">
	  
	  <table cellspacing="55px" cellpadding="25px">
	  <tr>
	   <td><img src="pic/z1.jpg" class="hover-bg">
	   </img><div class="container">
 
  <div class="middle">
    <div class="text">RECESSED LIGHTING </div>
  </div>
</div></td>
	   <td><img src="pic/z2.jpg" class="hover-bg"></img> 
	   <div class="container">
	   <div class="middle">
    <div class="text">CELING EFFECT</div>
  </div></div></td>
	   <td><img src="pic/u3.jpg" class="hover-bg"></img><div class="container"> <div class="middle">
    <div class="text">CARPET LIGHT LOOK</div></div>
  </div></td>
	  </tr>
	  <tr>
	  <td><img src="pic/z3.jpg" class="hover-bg"></img>
	  </img><div class="container">
 
               <div class="middle">
                     <div class="text">WALL PAPER LOOK </div>
                     </div></div>
					 </td>
	  <td><img src="pic/u2.jpg" class="hover-bg"></img>
	  </img><div class="container">
 
       <div class="middle">
              <div class="text">PAINTING STRUCTURE </div>
                    </div></div>
	</td>
	  <td><img src="pic/z4.jpeg" class="hover-bg"></img>
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">CURTAINS LOOK </div> </div></div>
</td>
	  </tr>
	  <tr>
	  <td><img src="pic/u4.jpg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">CARPET DESIGN </div> </div></div>
	</td>
	  <td><img src="pic/z5.jpeg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">CHILDREN WALLPAPER </div> </div></div>
	</td>
	  <td><img src="pic/z6.jpg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">CARPET ALIGNMENT</div> </div></div>
	</td>
	  </tr>
	  <tr>
	  <td><img src="pic/z7.jpg" class="hover-bg"></img>
	   
	 
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">LOVELY LIGHTING</div> </div></div>
	</td>
	  <td><img src="pic/u5.jpg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text" >BUTTERFLY GLASS PAINT </div> </div></div>
	</td>
	  <td><img src="pic/z8.jpg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">HOMELY PAINTING </div> </div></div>
	</td>
	  </tr>
	  <tr>
	  <td><img src="pic/z9.jpg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">PEGASUS LOOK </div> </div></div>
	</td>
	  <td><img src="pic/u1.jpg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">FLOWER EFFECT </div> </div></div>
	</td>
	  <td><img src="pic/z10.jpg" class="hover-bg"></img>
	  
	  </img><div class="container">
 
             <div class="middle">
    <div class="text">BLACK AND WHITE MEMORIES </div> </div></div>
	</td>
	  </tr>
	  </table>
      </div>
    </div>
  </div>
</div>
						


			<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>About Us</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore dolore magna aliqua.
								</p>
							</div>
						</div>
						<div class="col-lg-4  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Contact Us</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore dolore magna aliqua.
								</p>
								<p class="number">
									012-6532-568-9746 <br>
									012-6532-569-9748
								</p>
							</div>
						</div>						
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Newsletter</h4>
								<p>You can trust us. we only send  offers, not a single spam.If you want a golden rule that will fit everything, this is it: Have nothing in your houses that you do not know to be useful or believe to be beautiful.</p>
								
							</div>
						</div>						
					</div>
					<div class="footer-bottom row">
						<p class="footer-text m-0 col-lg-6 col-md-12">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.

						</p>
						
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>				
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>	
			<script src="js/waypoints.min.js"></script>
			<script src="js/jquery.counterup.min.js"></script>			
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>



