<?php
require 'master/PHPMailerAutoload.php'; 
session_start();
$name = $_POST["name"];
$pass= $_POST["pass"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$address = $_POST["address"];
$taddress = $_POST["taddress"];
$conn=mysqli_connect("localhost","root");
mysqli_select_db($conn,"looklet");
if ($conn->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$check="SELECT email from `registration` where  `email`='$email' ";
$selection = mysqli_query( $conn, $check );
if(mysqli_num_rows($selection)>=1)
{
	$_SESSION['Error'] = "Email Id Already Exist!";
	header('location:reg.php');
}
else
{
$select = "insert into registration(name,password,email,phone,paddress,taddress)values('".$name."','".$pass."','".$email."','".$phone."','".$address."','".$taddress."')";
$sql=mysqli_query($conn,$select);
            $name=$_POST['name'];
            $mail=$_POST['email'];
            $mailto = $mail;
            $mailSub = "Registration Confirmation...";
            $mailMsg = "Thank You for Registering with Smart Looklet! Let's start your Online Shopping Journey.....".$name;
            $mail = new PHPMailer();
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "smtp.gmail.com";
            $mail ->Port = 465; // or 587
            $mail ->IsHTML(true);
            $mail ->Username = "smartlooklet@gmail.com";

            $mail ->Password = "Smart@123";
            $mail ->SetFrom("smartlooklet@gmail.com");
            $mail ->Subject = $mailSub;
            $mail ->Body = $mailMsg;
            $mail ->AddAddress($mailto);

            if($mail->Send())
             {
                 echo "<script>";
                 echo "alert('Mail Sent successfully....');";
                 echo "window.location.href='login.php';</script>";
             }
            else
             {
                  echo "<script>";
                 echo "alert('Mail not Sent successfully....');";
                 echo "window.location.href='reg.php';</script>";              
             }
                  
header('location:login.php');    

 
    
}
//echo $select."2";

echo mysqli_error($conn);

mysqli_close($conn);
?>