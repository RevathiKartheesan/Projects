<?php 
	session_start();
	$name = $password = "";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$name = $_POST["name"];
		$password = $_POST["pass"];
		$_SESSION['name']=$name;
	}
	
	$servername = "localhost";
	
	// Create connection
	$conn = new mysqli($servername, "root", "");
	
	// Check connection
	if($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	mysqli_select_db($conn, 'looklet');

	$selectionQuery = "SELECT email, password FROM registration where email = '$name' and password = '$password'";
	   	
	$selection = mysqli_query( $conn, $selectionQuery );
		if(mysqli_num_rows($selection)!=1)
	{
		$_SESSION['Error'] = "Invalid User Name or Password!";
		header('location:login.php');
	}
	else
	{
	while($row = mysqli_fetch_array($selection)) {
		
	if($row['email'] == ""  or $row['password'] == "") {
			
			echo "Invalid Credentials";
			
					}			
		
		else {
		
			
	         header("location:payment.php");
		
		}
		
	}
	}
?>