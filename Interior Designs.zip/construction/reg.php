	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="codepixer">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Plans</title>
        <style>
		 h1,h3{
		font-size:10px;
		}
		</style>
		<script>
function val()
{
 x=document.f;
 p=x.phone.value;
 p1=x.pass.value;
 p2=x.pass1.value;
 ph=x.name.value;
 em=x.email.value.indexOf("@")
 m=0
 if(p.length!=10 || p<6000000000 || p>9999999999)
 {
  alert("Not a valid phone number!!!")
  m=1
 }
 if(p1!=p2 || p1=="" || p2=="")
 {
  alert("Not valid password!!!")
  m=1
 }
 if(isNaN(ph)==false)
 {
  alert("Not a valid name!!!")
  m=1
 }
 if(em==-1)
 {
  alert("Not a valid Email ID") 
  m=1
 }
 if(x.c1.checked==false || x.c2.checked==false)
 {
 alert("Please accept our terms and conditions!")
 m=1
 }
}
</script>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">	
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>
<?php
							
							
							session_start();
							$name=$_SESSION['name'];
							$email = $_POST["email"];
							$conn=mysqli_connect("localhost","root");
mysqli_select_db($conn,"looklet");
$check="SELECT email from `registration` where  `email`='$email' ";
							$selection = mysqli_query( $conn, $check );
if(mysqli_num_rows($selection)>=1)
{
	$_SESSION['Error'] = "Email Id Already Exist!";

}
  ?>
			  <header id="header" id="home">
			    <div class="container">
			    	<div class="row header-top align-items-center">
			    		<div class="col-lg-4 col-sm-4 menu-top-left">
			    			<img src="pic/l2.jpg" width="15%" height="15%"></img>
			    			<a class="tel" href="mailto:smartlooklet@gmail.com">smartlooklet@gmail.com</a>
			    		</div>
			    		<div class="col-lg-4 menu-top-middle justify-content-center d-flex">
							<a href="index.html">
								<h1>SMART LOOKLET</h1>	
							</a>			    			
			    		</div>
			    		<div class="col-lg-4 col-sm-4 menu-top-right">
			    			<a class="tel" href="tel:+777 000 22299">+777 000 22299</a>
			    			<img src="pic/l1.jpg" width="15%" height="15%"></img>
							<h1 style="color:red;font-size:20px;"><?=$name?></h1>
			    		</div>
			    	</div>
			    </div>	
			    	<hr>
			    <div class="container">	
			    	<div class="row align-items-center justify-content-center d-flex">
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="index.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
						  <li><a href="project.php">Project</a></li>
						  <li><a href="cart.php">Order</a></li>
				          <li><a href="contact.php">Contact</a></li>
						  <li><a href="admin.php">Admin</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Registration page		
							</h1>	
							
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start price Area -->
			<section class="price-area section-gap">
			<div id="gra">
				<form name="f" action = "regis.php" method="post" align="center" style="border-width:20px;">
<font>
<div id="qwe" style="color:black;">
<h1><center><bold>REGISTER LOGIN</bold></center></h1>
<center>
<?php
if( isset($_SESSION['Error']) )
{
        echo $_SESSION['Error'];

        unset($_SESSION['Error']);

}
?>
<table cellpadding="10" cellspacing="10px" border="4px">
<h3><tr><td>Name:</td><td><input name="name" align="right" required></td></tr></h3>
<h3><tr><td>Email: </td><td><input name="email" required></tr></td></h3>
<h3><tr><td>password:</td><td><input type="password" name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain atleast 1 number and one upper case and lower case letter and atleast 8 or more characters"> </tr></td></h3>
<h3><tr><td>Reenter password:</td><td><input type="password" name="pass1"></tr></td> </h3>
<h3><tr><td>Permanant address:</td><td><textarea name="address" rows="5" cols="20"></textarea></tr></td></h3>
<h3><tr><td>Temporary address:</td><td><textarea name="taddress" rows="5" cols="20"></textarea></tr></td></h3>
<tr><td>Phone:</td><td><input name="phone" placeholder="Enter phone no."></tr></td></h3><br><br>
</table><br>
<h3 style="font-size:15px;" ><input type="checkbox" name="c1">I aggreed with the above information</h3><br>
<h3 style="font-size:15px;"><input type="checkbox" name="c2"> The above given information is given with my console</h3><br>
<center><input type="submit" name="del" onclick="val()" /></center>

</center>
</div>
</font>
</form>
			</div>
				</section>
			<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>About Us</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore dolore magna aliqua.
								</p>
							</div>
						</div>
						<div class="col-lg-4  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Contact Us</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore dolore magna aliqua.
								</p>
								<p class="number">
									012-6532-568-9746 <br>
									012-6532-569-9748
								</p>
							</div>
						</div>						
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Newsletter</h4>
								<p>You can trust us. we only send  offers, not a single spam.</p>
								<div class="d-flex flex-row" id="mc_embed_signup">


									  
								</div>
							</div>
						</div>						
					</div>
					<div class="footer-bottom row">
						<p class="footer-text m-0 col-lg-6 col-md-12">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
						</p>
						
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>				
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>	
			<script src="js/waypoints.min.js"></script>
			<script src="js/jquery.counterup.min.js"></script>			
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>



