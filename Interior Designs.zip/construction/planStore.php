<?php
session_start();
$email=$_SESSION['name'];
if(isset($_POST['sub1'])){
		$_SESSION['plan']=$_POST['val1'];
	}
	else if(isset($_POST['sub2'])){
		$_SESSION['plan']=$_POST['val2'];
	}
	else if(isset($_POST['sub3'])){
		$_SESSION['plan']=$_POST['val3'];
	}
	else if(isset($_POST['sub4'])){
		$_SESSION['plan']=$_POST['val4'];
		}
$conn=mysqli_connect("localhost","root");
mysqli_select_db($conn,"looklet");
if ($conn->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
if($email=="")
{
	echo "<alert>Please Login to continue</alert>";
}
else if($_SESSION['flag1']==0)
{
	$_SESSION['flag1']=1;
	header("location:pay.php");
}	
if($_POST['hid']==1)
{
	$email=$_SESSION['name'];
	$plan=$_SESSION['plan'];
	$check="UPDATE `registration` set `Plan`='$plan' where `email`='$email' ";
	$selection = mysqli_query( $conn, $check );
	header("location:cart.php");
}		
	?>