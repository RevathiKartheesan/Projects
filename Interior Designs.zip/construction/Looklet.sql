-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2019 at 01:19 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `looklet`
--

-- --------------------------------------------------------

--
-- Table structure for table `paycart`
--

CREATE TABLE `paycart` (
  `name` varchar(100) NOT NULL,
  `no` int(100) NOT NULL,
  `cvv` int(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paycart`
--

INSERT INTO `paycart` (`name`, `no`, `cvv`, `type`, `date`) VALUES
('ytrewa', 2147483647, 654, 'Debit Card', '2019-07'),
('ytrewa', 2147483647, 765, 'Debit Card', '2019-05'),
('soundariya', 345667, 890, 'Credit Card', '2019-02'),
('7778', 2147483647, 77987, 'Debit Card', '2019-01'),
('hhdgg7', 23456789, 7436, 'Credit Card', '2019-02'),
('soundariya', 23456789, 456789, 'Debit Card', ''),
('hhdgg7', 2147483647, 678, 'Debit Card', ''),
('ytrewa', 2147483647, 789, 'Debit Card', ''),
('hhdgg7', 2147483647, 657, 'Debit Card', ''),
('soundariya', 2147483647, 345, 'Debit Card', '');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `name` varchar(90) NOT NULL,
  `password` varchar(23) NOT NULL,
  `email` varchar(89) NOT NULL,
  `phone` int(100) NOT NULL,
  `paddress` varchar(100) NOT NULL,
  `taddress` varchar(100) NOT NULL,
  `Plan` text NOT NULL,
  `amount` int(100) NOT NULL,
  `Feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`name`, `password`, `email`, `phone`, `paddress`, `taddress`, `Plan`, `amount`, `Feedback`) VALUES
('Anu', 'Renu@123', 'revathikarthik234@gmail.com', 2147483647, 'edtfyguhjk', 'dfghjk', 'Diamond', 56552, 'dddffhjnnkkml,'),
('RASIKA', 'Rasika@22', 'rasikakathirvel@gmail.com', 2147483647, 'drtyd', 'fdhf', 'Silver', 13194, 'good');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
