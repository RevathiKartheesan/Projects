<?php
session_start();

$email=$_SESSION['name'];
	if($email=="")
	{
		header("location:login.php");
	}
	else if($_SESSION['flag']==0){
				$_SESSION['tot']=$_POST['total'];
		$_SESSION['flag']=1;
		header("location:payment.php");

	}

	if($_POST['hid']==1)
	{
		$tot1=$_SESSION['tot'];
$email=$_SESSION['name'];
$conn=mysqli_connect("localhost","root");
mysqli_select_db($conn,"looklet");
if ($conn->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$check="UPDATE `registration` set `amount`='$tot1' where `email`='$email' ";
$selection = mysqli_query( $conn, $check );
header("location:index.php");
	}
	
	
?>