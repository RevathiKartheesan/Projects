<?php
   $conn=mysqli_connect("localhost","root");
   mysqli_select_db($conn,"looklet");
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($conn,$_POST['uname']);
      $mypassword = mysqli_real_escape_string($conn,$_POST['pwd']); 
      
      $sql = "SELECT id FROM registration WHERE name = '.$myusername.' and password = '.$mypassword.'";
      $result = mysqli_query($conn,$sql);

      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         $_SESSION['login_user'] = $myusername;
         
         header("location: pay.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>