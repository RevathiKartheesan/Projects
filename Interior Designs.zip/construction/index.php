<!DOCTYPE html>
	<html lang="zxx" class="no-js">

<head>
<!-- Mobile Specific Meta --><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Favicon--><link rel="shortcut icon" href="img/fav.png"><!-- Author Meta -->
<meta name="author" content="codepixer"><!-- Meta Description -->
<meta name="description" content=""><!-- Meta Keyword -->
<meta name="keywords" content=""><!-- meta character set -->
<meta charset="UTF-8">

<!-- Site Title --><title>Warehouse</title>
<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/magnific-popup.css">
	
<link rel="stylesheet" href="css/nice-select.css">
<link rel="stylesheet" href="css/animate.min.css">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="css/owl.carousel.css">
<link rel="stylesheet" href="css/main.css">

</head>


<body>
<?php
							
							
							session_start();
							$name=$_SESSION['name'];
      ?>
<header id="header" id="home">
<div class="container">
<div class="row header-top align-items-center">
<div class="col-lg-4 col-sm-4 menu-top-left">
<img src="pic/l2.jpg" width="15%" height="15%"></img>

<a class="tel" href="mailto:smartlooklet@gmail.com">smartlooklet@gmail.com</a>
</div>
<div class="col-lg-4 menu-top-middle justify-content-center d-flex">

<h1>SMART LOOKLET</h1>

</div>
<div class="col-lg-4 col-sm-4 menu-top-right">
<a class="tel" href="tel:+777 000 22299">+777 000 22299</a>
<img src="pic/l1.jpg" width="15%" height="15%"></img>
<h1 style="color:red;font-size:20px;"><?=$name?></h1>
</div></div></div><hr><div class="container">
<div class="row align-items-center justify-content-center d-flex">
<nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="index.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
						  <li><a href="project.php">Project</a></li>
						  <li><a href="cart.php">Order</a></li>
				          <li><a href="contact.php">Contact</a></li>
						  <li><a href="admin.php">Admin</a></li>
				        </ul>
				      </nav>
<!-- #nav-menu-container --></div></div></header><!-- #header -->

<!-- start banner Area -->
<section class="banner-area relative" id="home">
<div class="overlay overlay-bg"></div>
<div class="container">
<div class="row d-flex align-items-center justify-content-center">
<div class="about-content col-lg-12">
<h1 class="text-white">	 Home</h1>
</div></div></div>
  </section><!-- End banner Area --><!-- Start blog-posts Area -->
  <section class="blog-posts-area section-gap">
  <div class="container">
  <div class="row">
<div class="col-lg-8 post-list blog-post-list">
<div class="single-post">
<img class="img-fluid" src="pic/y1.jpg" alt="">
<ul class="tags">	
<li><a href="#">Art, </a></li>
<li><a href="#">Technology, </a></li>
<li><a href="#">Fashion</a></li>
</ul>
<h1>Create with heart and live with peaceful mind	</h1>
<p>How you bring people into your home is just as important as when they walk through the door. Frame well......as you like..It is not a beauty of the building you should look at.its the construction of foundation that will stand the test of time.
</p>
								
							</div>
							<div class="single-post">
								<img class="img-fluid" src="pic/y2.jpg" alt="">
								
								
									<h1>
										Proportion is the heart of beauty.
									</h1>
								
									<p>
										Each of us is carving a stone, erecting a column, or cutting a piece of stained glass in the construction of something much bigger than ourselves....You can design and create, and build the most wonderful place in the world. But it takes people to make the dream a reality</p>
								
							</div>
							<div class="single-post">
								<img class="img-fluid" src="pic/y3.jpg" width="500px" height="500px" alt="">
								<ul class="tags">
									<li><a href="#">Art, </a></li>
									<li><a href="#">Technology, </a></li>
									<li><a href="#">Fashion</a></li>
								</ul>
								
									<h1>
									Whatever good things we built to end up building us	
									</h1>
								
									<p>A world which sees art and engineering as divided is not seeing the world as a whole.The intrinsic nature of life is to make an effort to move ahead, to grow and to achieve success. 
Even a small seed has to break ground in its struggle to grow into a mighty tree	</p>
							
							</div>
							<div class="single-post">
								<img class="img-fluid" src="pic/y4.jpg" alt="">
								<ul class="tags">
									<li><a href="#">Art, </a></li>
									<li><a href="#">Technology, </a></li>
									<li><a href="#">Fashion</a></li>
								</ul>
								
									<h1>
									Pathway in the spirit to be made, it is the way of godliness	
									</h1>
								
									<p>
										Contrary to popular belief, diamond is not the hardest material known to man. The hardest material in the universe is dried egg yolk. And one day, it will revolutionize the construction industry.
									</p>
								
							</div>																					
						</div>
						<div class="col-lg-4 sidebar">
							<div class="single-widget search-widget">

							<div class="single-widget protfolio-widget">
								<img src="pic/y5.jpg" width="150px" height="150px" alt="">
								<a href="#"><h4>Caile</h4></a>
								<p>
									Website looks good and smart work....some of the development to be needed and also your way attraction is differ from others.
								</p>
																
							</div>

							<div class="single-widget category-widget">
								<h4 class="title">Recently purchased Categories</h4>
								<ul>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Lightings</h6> <span>37 </span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Curtains</h6> <span>24</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Carpets</h6> <span>59</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Wallpaper Designs</h6> <span>29</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Paintings</h6> <span>15</span></a></li>
								</ul>
							</div>

							<div class="single-widget recent-posts-widget">
								<h4 class="title">Recent Posts</h4>
								<div class="blog-list ">
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="pic/image4.jpg" alt="">
										</div>
										<div class="recent-details">
											
												<h4>
													Home decoration
												</h4>
											
											<p>
												02 hours ago
											</p>
										</div>
									</div>	
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="pic/door.jpg" alt="" width="260pt">
										</div>
										<div class="recent-details">
											
											
												<h4>
													Comfort Environment
												</h4>
											
											<p>
												02 hours ago
											</p>
										</div>
									</div>	
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="pic/pain.jpg" alt="" width="203pt">
										</div>
										<div class="recent-details">
											
												<h4>
													Paintings
												</h4>
											</a>
											<p>
												03 hours ago
											</p>
										</div>
									</div>	
									<div class="single-recent-post d-flex flex-row">
										<div class="recent-thumb">
											<img class="img-fluid" src="pic/int.jpg" alt="" width="450pt">
										</div>
										<div class="recent-details">
											
												<h4>
													Looking of attractive lightening ideas
												</h4>
											
											<p>
												02 hours ago
											</p>
										</div>
									</div>																																					
								</div>								
							</div>

							<div class="single-widget category-widget">
								<h4 class="title">Recently Purchased </h4>
								<ul>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Dec '18</h6> <span>37</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Nov '18</h6> <span>24</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Nov '18</h6> <span>59</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>oct '18</h6> <span>29</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Sep '18</h6> <span>15</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Jul '18</h6> <span>09</span></a></li>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Jun '18</h6> <span>44</span></a></li>
								</ul>
							</div>			

							<div class="single-widget tags-widget">
								<h4 class="title">Tag moments</h4>
								 <ul>
								 	<li><a href="#">Lightings</a></li>
								 	<li><a href="#">Curtains</a></li>
								 	<li><a href="#">Carpets</a></li>
								 	<li><a href="#">Wallpaper Designs</a></li>
								 	<li><a href="#">Paintings</a></li>
								 </ul>
							</div>				

						</div>
					</div>
				</div>	
			</section>
			<!-- End blog-posts Area -->
			

			<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>About Us</h4>
								<p>
								 The longer I live, the more beautiful life becomes. If you foolishly ignore beauty, you will soon find yourself without it. Your life will be impoverished. But if you invest in beauty, it will remain with you all the days of your life.
								</p>
							</div>
						</div>
						<div class="col-lg-4  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Contact Us</h4>
								<p>
								+777 000 22299
									</p>
								<p class="number">
									012-6532-568-9746 <br>
									012-6532-569-9748
								</p>
							</div>
						</div>						
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Newsletter</h4>
								<p>You can trust us. we only send  offers, not a single spam.If you want a golden rule that will fit everything, this is it: Have nothing in your houses that you do not know to be useful or believe to be beautiful.</p>
								
							</div>
						</div>						
					</div>
					<div class="footer-bottom row">
						<p class="footer-text m-0 col-lg-6 col-md-12">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.
						</p>
						
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>				
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>	
			<script src="js/waypoints.min.js"></script>
			<script src="js/jquery.counterup.min.js"></script>			
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>