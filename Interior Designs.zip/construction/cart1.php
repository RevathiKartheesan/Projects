<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Order</title>
	<!--/tags -->
	<style>
.single {
  padding: 10px 20px;
  font-size: 20px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: green;
  background-color: BlanchedAlmond ;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.single:hover {background-color: LightCoral }

.single:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
    
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Grocery Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<!--pop-up-box-->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!--//pop-up-box-->
	<!-- price range -->
	<link rel="stylesheet" type="text/css" href="css/jquery-ui1.css">
	<!-- fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
            <link rel="stylesheet" href="css/linearicons.css">
            <link rel="stylesheet" href="css/font-awesome.min.css">
            <link rel="stylesheet" href="css/bootstrap.css">
            <link rel="stylesheet" href="css/magnific-popup.css">
            <link rel="stylesheet" href="css/nice-select.css">                  
            <link rel="stylesheet" href="css/animate.min.css">
            <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">  
            <link rel="stylesheet" href="css/owl.carousel.css">
            <link rel="stylesheet" href="css/main.css">
            <script type="text/javascript">
	var tot=0,pro1=0,pro2=0,pro3=0,pro4=0,pro5=0,pro6=0,pro7=0,pro8=0,pro9=0,pro10=0,pro11=0,pro12=0,pro13=0,pro14=0,pro15=0,pro16=0,pro17=0,pro18=0,pro19=0,pro20=0,pro21=0,pro22=0,pro23=0,pro24=0,pro25=0,pro26=0,pro27=0,pro28=0,pro29=0,pro30=0,pro31=0,pro32=0,pro33=0,pro34=0,pro35=0,pro36=0
	function add(a,b){
	
		if(b=="pro1")
			pro1+=1
		else if(b=="pro2")
			pro2+=1
		else if(b=="pro3")
			pro3+=1
		else if(b=="pro4")
			pro4+=1
		else if(b=="pro5")
			pro5+=1
		else if(b=="pro6")
			pro6+=1
		else if(b=="pro7")
			pro7+=1
		else if(b=="pro8")
			pro8+=1
		else if(b=="pro9")
			pro9+=1
		else if(b=="pro10")
			pro10+=1
		else if(b=="pro11")
			pro11+=1
		else if(b=="pro12")
			pro12+=1
		else if(b=="pro13")
			pro13+=1
		else if(b=="pro14")
			pro14+=1
		else if(b=="pro15")
			pro15+=1
		else if(b=="pro16")
			pro16+=1
		else if(b=="pro17")
			pro17+=1
		else if(b=="pro18")
			pro18+=1
		else if(b=="pro19")
			pro19+=1
		else if(b=="pro20")
			pro20+=1
		else if(b=="pro21")
			pro21+=1
		else if(b=="pro22")
			pro22+=1
		else if(b=="pro23")
			pro23+=1
		else if(b=="pro24")
			pro24+=1
		else if(b=="pro25")
			pro25+=1
		else if(b=="pro26")
			pro26+=1
		else if(b=="pro27")
			pro27+=1
		else if(b=="pro28")
			pro28+=1
		else if(b=="pro29")
			pro29+=1
		else if(b=="pro30")
			pro30+=1
		else if(b=="pro31")
			pro31+=1
		else if(b=="pro32")
			pro32+=1
		else if(b=="pro33")
			pro33+=1
		else if(b=="pro34")
			pro34+=1
		else if(b=="pro35")
			pro35+=1
		else if(b=="pro36")
			pro36+=1
		tot+=a
	}
	function remove(a,b){
		if(tot!=0){
		if(b=="pro1"){
			if(pro1==0)
			{
				alert(" Pendants is not yet added in the cart")
			}
			else
			{
			pro1-=1
			tot-=a
		}
		}
		else if(b=="pro2"){
			if(pro2==0)
			{
				alert("Wall scones is not yet added in the cart")
			}
			else
			{
			pro2-=1
			tot-=a
			}
		}
		else if(b=="pro3"){
			if(pro3==0)
			{
				alert("Floor lamps is not yet added in the cart")
			}
			else
			{
			pro3-=1
			tot-=a
			}
		}
		else if(b=="pro4"){
			if(pro4==0)
			{
				alert("Track lighting is not yet added in the cart")
			}
			else
			{
			pro4-=1
			tot-=a
			}
		}
		else if(b=="pro5"){
			if(pro5==0)
			{
				alert("Chandeliers is not yet added in the cart")
			}
			else
			{
			pro5-=1
			tot-=a
			}
		}
		else if(b=="pro6"){
			if(pro6==0)
			{
				alert("Ceiling is not yet added in the cart")
			}
			else
			{
			pro6-=1
			tot-=a
			}
		}
		else if(b=="pro7"){
			if(pro7==0)
			{
				alert("Recessed is not yet added in the cart")
			}
			else
			{
			pro7-=1
			tot-=a
			}
		}
		else if(b=="pro8"){
			if(pro8==0)
			{
				alert("Box Pleated Curtains is not yet added in the cart")
			}
			else
			{
			pro8-=1
			tot-=a
			}
		}
		else if(b=="pro9"){
			if(pro9==0)
			{
				alert("Pinch Pleated Curtains is not yet added in the cart")
			}
			else
			{
			pro9-=1
			tot-=a
			}
		}
		else if(b=="pro10"){
			if(pro10==0)
			{
				alert("Eyelet Curtains is not yet added in the cart")
			}
			else
			{
			pro10-=1
			tot-=a
			}
		}
		else if(b=="pro11"){
			if(pro11==0)
			{
				alert("Tailored Pleat Curtains is not yet added in the cart")
			}
			else
			{
			pro11-=1
			tot-=a
			}
		}
		else if(b=="pro12"){
			if(pro12==0)
			{
				alert("Goblet Pleat Curtains is not yet added in the cart")
			}
			else
			{
			pro12-=1
			tot-=a
			}
		}
		else if(b=="pro13"){
			if(pro13==0)
			{
				alert("Sheer Curtains is not yet added in the cart")
			}
			else
			{
			pro13-=1
			tot-=a
			}
		}
		else if(b=="pro14"){
			if(pro14==0)
			{
				alert("Pelmets and Valances is not yet added in the cart")
			}
			else
			{
			pro14-=1
			tot-=a
			}
		}
		else if(b=="pro15"){
			if(pro15==0)
			{
				alert("Hanging curtains is not yet added in the cart")
			}
			else
			{
			pro15-=1
			tot-=a
			}
		}
		else if(b=="pro16"){
			if(pro16==0)
			{
				alert("Acrylic is not yet added in the cart")
			}
			else
			{
			pro16-=1
			tot-=a
			}
		}
		else if(b=="pro17"){
			if(pro17==0)
			{
				alert("Blends is not yet added in the cart")
			}
			else
			{
			pro17-=1
			tot-=a
			}
		}
		else if(b=="pro18"){
			if(pro18==0)
			{
				alert("Nylon is not yet added in the cart")
			}
			else
			{
			pro18-=1
			tot-=a
			}
		}
		else if(b=="pro19"){
			if(pro19==0)
			{
				alert("Polyester is not yet added in the cart")
			}
			else
			{
			pro19-=1
			tot-=a
			}
		}
		else if(b=="pro20"){
			if(pro20==0)
			{
				alert("Olefin Or Polypropylene is not yet added in the cart")
			}
			else
			{
			pro20-=1
			tot-=a
			}
		}
		else if(b=="pro21"){
			if(pro21==0)
			{
				alert("Polyester Recycled Carpet Fiber is not yet added in the cart")
			}
			else
			{
			pro21-=1
			tot-=a
			}
		}
		else if(b=="pro22"){
			if(pro22==0)
			{
				alert("Wool is not yet added in the cart")
			}
			else
			{
			pro22-=1
			tot-=a
			}
		}
		else if(b=="pro23"){
			if(pro23==0)
			{
				alert("Flower is not yet added in the cart")
			}
			else
			{
			pro23-=1
			tot-=a
			}
		}
		else if(b=="pro24"){
			if(pro24==0)
			{
				alert("Butterfly is not yet added in the cart")
			}
			else
			{
			pro24-=1
			tot-=a
			}
		}
		else if(b=="pro25"){
			if(pro25==0)
			{
				alert("Nature is not yet added in the cart")
			}
			else
			{
			pro25-=1
			tot-=a
			}
		}
		else if(b=="pro26"){
			if(pro26==0)
			{
				alert("Modern is not yet added in the cart")
			}
			else
			{
			pro26-=1
			tot-=a
			}
		}
		else if(b=="pro27"){
			if(pro27==0)
			{
				alert("Office is not yet added in the cart")
			}
			else
			{
			pro27-=1
			tot-=a
			}
		}
		else if(b=="pro28"){
			if(pro28==0)
			{
				alert("Restaurant is not yet added in the cart")
			}
			else
			{
			pro28-=1
			tot-=a
			}
		}
		else if(b=="pro29"){
			if(pro29==0)
			{
				alert("Galaxy is not yet added in the cart")
			}
			else
			{
			pro29-=1
			tot-=a
			}
		}
		else if(b=="pro30"){
			if(pro30==0)
			{
				alert("Acrylic is not yet added in the cart")
			}
			else
			{
			pro30-=1
			tot-=a
			}
		}
		else if(b=="pro31"){
			if(pro31==0)
			{
				alert("Nigeris is not yet added in the cart")
			}
			else
			{
			pro31-=1
			tot-=a
			}
		}
		else if(b=="pro32"){
			if(pro32==0)
			{
				alert("Sunset is not yet added in the cart")
			}
			else
			{
			pro32-=1
			tot-=a
			}
		}
		else if(b=="pro33"){
			if(pro33==0)
			{
				alert("Cartoon is not yet added in the cart")
			}
			else
			{
			pro33-=1
			tot-=a
			}
		}
		else if(b=="pro34"){
			if(pro34==0)
			{
				alert("Canvas is not yet added in the cart")
			}
			else
			{
			pro34-=1
			tot-=a
			}
		}
		else if(b=="pro35"){
			if(pro35==0)
			{
				alert("Scenary is not yet added in the cart")
			}
			else
			{
			pro35-=1
			tot-=a
			}
		}
		else if(b=="pro36"){
			if(pro36==0)
			{
				alert("Diy is not yet added in the cart")
			}
			else
			{
			pro36-=1
			tot-=a
			}
		}
		
		
		}
		else
			alert("Cart is empty")
	}

</script>
</head>

<body>
<?php
							
							
							session_start();
							$name=$_SESSION['name'];
      ?>
<header id="header" id="home">
                <div class="container">
                    <div class="row header-top align-items-center">
                        <div class="col-lg-4 col-sm-4 menu-top-left">
                           <img src="pic/l2.jpg" width="15%" height="15%"></img>
                            <a class="tel" href="mailto:smartlooklet@gmail.com">smartlooklet@gmail.com</a>
                        </div>
                        <div class="col-lg-4 menu-top-middle justify-content-center d-flex">
                           
                                <h1>SMART LOOKLET</h1>   
                           
                        </div>
                        <div class="col-lg-4 col-sm-4 menu-top-right">
                            <a class="tel" href="tel:+777 000 22299">+777 000 22299</a>
                            <img src="pic/l1.jpg" width="15%" height="15%"></img>
							<h1 style="color:red;font-size:20px;"><?=$name?></h1>
                        </div>
                    </div>
                </div>  
                    <hr>
                <div class="container"> 
                    <div class="row align-items-center justify-content-center d-flex">
                      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li ><a href="index.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
						  <li><a href="project.php">Project</a></li>
						  <li><a href="login.php">Get Plan</a></li>
				          <li class="menu-active"><a href="cart.php">Order</a></li>
				          <li><a href="contact.php">Contact</a></li>
						  <li><a href="admin.php">Admin</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->                    
                    </div>
                </div>
              </header><!-- #header -->

            <!-- start banner Area -->
            <section class="banner-area relative" id="home">    
                <div class="overlay overlay-bg"></div>
                <div class="container">
                    <div class="row d-flex align-items-center justify-content-center">
                        <div class="about-content col-lg-12">
                            <h1 class="text-white">
                                Order              
                            </h1>   
                            
                        </div>                                          
                    </div>
                </div>
            </section>
            <!-- End banner Area -->    
			<div class="ads-grid">
	
				<!-- cart details -->
				<div class="top_nav_right">
					<div class="wthreecartaits wthreecartaits2 cart cart box_1">
						<form action="#" method="post" class="last">
							<input type="hidden" name="cmd" value="_cart">
							<input type="hidden" name="display" value="1">
							<button class="w3view-cart" type="submit" name="submit" value="">
								<i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
							</button>
						</form>
					</div>
				</div>
				<!-- //cart details -->
			<!-- product right -->
		
			<div class="agileinfo-ads-display col-md-9 w3l-rightpro">
			
				<div class="wrapper">
				
					<!-- first section -->
					<div class="product-sec1">
					
						
			<!-- tittle heading -->
			<center>
			<h3>Lightning
			
			</h3></center>
			<table cellpadding="20"><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/q7.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">This kind of fixtures is suspended from the ceiling and direct light downwards, for example a kitchen island or a table. It adds to the decorative element of a given space.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
										Pendants
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.2599.00/-</span>
										<del>$4020.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Pendants" />
												<input type="hidden" name="amount" value="2599.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input class="single" type="submit" name="submit" value="Add to cart" class="button" /><br><br>
												<button class="single" type="submit" name="submit" >Remove from cart</button>
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div></td><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/q6.jpg" width="37%" height="200px"></img><br><br>
											<h6 style="font-size:15px;">
Mounted to the wall surface, scones have the ability to direct light either upwards or downwards or in both the directions, adding style to the space.</h6>

									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
										Wall scones
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.1999.00</span>
										<del>Rs.2399.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Wall scones" />
												<input type="hidden" name="amount" value="1999.00" />
												<input type="hidden" name="discount_amount" value="2.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div></td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/q5.jpg" width="37%" height="200px"></img><br><br>
									
										<h6 style="font-size:15px;">In this lighting, the fixtures can either be mounted way high on a wall, in a horizontal shield, metal, wood,on the window, etc so that light bounces in the downward and upward direction.</h6>
									
									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
										Floor lamps
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.3999.00</span>
										<del>Rs.4290.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Floor lamps" />
												<input type="hidden" name="amount" value="3999.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="Rs" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>	</div>
							</div>	</div></td><td>
							
							<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/q4.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">Here a linear cable with several adjustable heads is fixed along a track.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
										Track lighting
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.4599.00/-</span>
										<del>$5239.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Track lighting" />
												<input type="hidden" name="amount" value="4599.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/q3.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">These decorative lightings are hung at the ceiling and suspend light towards the entryway or on a table. It brightens up the space beautifully.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
										Chandeliers
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.3999.00/-</span>
										<del>$4010.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Chandeliers" />
												<input type="hidden" name="amount" value="3999.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr></table>
						<!----curtains-->
						
						<center>
							<h3>CURTAINS
			</h3></center><table cellpadding="20"><tr><td style="width:50%;">
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/w1.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">Box pleated curtains give a very tailored look and drape into deep folds down the full length of the curtains. The box shapes line up next to each other which creates that formal, pleated look. They are ideal for more formal rooms like the lounge, dining or study.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
							Box Pleated Curtains
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.1599.00/-</span>
										<del>$3210.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Box Pleated Curtains" />
												<input type="hidden" name="amount" value="1599.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div></td><td style="width:50%">
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/w3.jpg" width="37%" height="200px"></img><br><br>
											<h6 style="font-size:15px;">
Eyelet curtains, or Grommet curtains are ideal for light to medium weight fabrics and include silver rings at the header that a rod weaves through.</h6>

									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
										Eyelet Curtains
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.1999.00</span>
										<del>Rs.1239.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Eyelet Curtains" />
												<input type="hidden" name="amount" value="1239.00" />
												<input type="hidden" name="discount_amount" value="2.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/w4.jpg" width="37%" height="200px"></img><br><br>
									
										<h6 style="font-size:15px;">tailored pleat drapes are similar to a Pinch Pleat, but the pleat starts at the top of the fabric and falls from there. Some people also call this a Euro pleat.</h6>
									
									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
									Tailored Pleat Curtains
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.679.00</span>
										<del>Rs.1390.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Tailored Pleat Curtains" />
												<input type="hidden" name="amount" value="679.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>	</div>
							</div>	</div>
							</td><td>
							<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/w5.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">very formal curtaining to suit a grand room in a traditional home with very high ceilings, the goblet pleat curtain is perfect. The pleat at the top resembles a wine glass.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
										Goblet Pleat Curtains
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.949.00/-</span>
										<del>$1639.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Goblet Pleat Curtains" />
												<input type="hidden" name="amount" value="949.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/w6.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">Sheer curtains bring a lightness to any window as their sheer fabric allows a little privacy while still filtering in light. Sheer curtains are often hung as secondary curtains or over blinds.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
										Sheer Curtains
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.599.00/-</span>
										<del>$690.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Sheer Curtains" />
												<input type="hidden" name="amount" value="599.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr></table>
									
						<!----carpets-->
						
						<center>
							<h3>CARPETS
				
			</h3>
		</center><table cellpadding="20"><tr><td style="width:50%">
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/ta1.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">Acrylic is made with a wool-like body that resists static and most stains. It is not likely to fade as much as other options.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
							Acrylic
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.1299.00/-</span>
										<del>$3210.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Acrylic" />
												<input type="hidden" name="amount" value="1299.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td><td style="width:50%">
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/ta2.jpg" width="37%" height="200px"></img><br><br>
											<h6 style="font-size:15px;">
keep in mind that blends also add the less desirable characteristics as well.</h6>

									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
										Blends
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.3999.00</span>
										<del>Rs.4539.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Blends" />
												<input type="hidden" name="amount" value="3999.00" />
												<input type="hidden" name="discount_amount" value="2.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/ta3.jpg" width="37%" height="200px"></img><br><br>
									
										<h6 style="font-size:15px;">Nylon is the most durable and stain resistant carpet fiber available, when treated with stain protection. It is the fiber of choice for homes with pets and children and for those who entertain a lot. Perfect for heavy traffic in hallways and stairs.</h6>
									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
								Nylon
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.1679.00</span>
										<del>Rs.1990.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Nylon" />
												<input type="hidden" name="amount" value="1679.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>	</div>
							</div>	</div>
							</td><td>
							<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/ta4.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">Polyester is known for its luxurious look, feel and wonderful selection of colors and styles. It's a good value for homes with a normal amount of traffic.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
Polyester
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.673.00/-</span>
										<del>$739.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Polyester" />
												<input type="hidden" name="amount" value="673.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/ta5.jpeg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">Olefin offers good stain and moisture resistance, but scores below nylon and polyester for wearability It is best suited for loop pile construction or high, very dense cut piles.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
										Olefin Or Polypropylene
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.591.00/-</span>
										<del>$690.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Olefin Or Polypropylene" />
												<input type="hidden" name="amount" value="591.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr></table>
	<!-- CARPET COMPLETED-->	

									
						<!----WALLPAPER DESIGNS-->
						<center>
							<h3>WALLPAPER DESIGNS
			</h3></center>
			<table cellpadding="20"><tr><td style="width:50%">
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/p2.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:20px;">Designer wallpaper, Floral bedroom and Grey floral wallpaper<br> elegant wallpaper design</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
							Flower
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.299.00/-</span>
										<del>$310.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Flower" />
												<input type="hidden" name="amount" value="299.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/p3.jpg" width="37%" height="200px"></img><br><br>
											<h6 style="font-size:15px;">
add a feminine feel to any room, ideal for feature walls and entire rooms.</h6>

									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
										Butterfly
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.499.00</span>
										<del>Rs.539.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Butterfly" />
												<input type="hidden" name="amount" value="499.00" />
												<input type="hidden" name="discount_amount" value="2.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/p5.jpg" width="37%" height="200px"></img><br><br>
									
										<h6 style="font-size:15px;">Stylish green murals,the majesty of nature has the ability to raise a room to new heights<br> A lovingly produced wall mural can go even furthe</h6>
									
									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
								Nature
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.679.00</span>
										<del>Rs.990.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Nature" />
												<input type="hidden" name="amount" value="679.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>	</div>
							</div>	</div>
							</td><td>
							<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/p1.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">geometrics to feminine florals<br>glamorous designer wallpaper to recreate any space</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
Modern
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.123.00/-</span>
										<del>$219.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Modern" />
												<input type="hidden" name="amount" value="123.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/p4.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">our selection of modern and elegant wallpapers.
<br>truly transform your Home Office into a working space you look forward to being in every day</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
										Office
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.591.00/-</span>
										<del>$690.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Office" />
												<input type="hidden" name="amount" value="591.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr></table>
	<!-- WALLPAPER COMPLETED-->		
	
						<!----PAINTINGS-->
						
						<center>
							<h3>PAINTINGS
			</h3>
			<table cellpadding="20"><tr><td style="width:50%">
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/a1.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">less affected by heat<br>the transparent brilliance of watercolour<br>the density of oil paint</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>
							Acrylic
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.259.00/-</span>
										<del>$350.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Acrylic" />
												<input type="hidden" name="amount" value="259.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td><td style="width:50%">
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/a2.jpg" width="37%" height="200px"></img><br><br>
											<h6 style="font-size:15px;">
oil on canvas paintings<br>go beyond paint and pencils<br>painted piece of artwork</h6>

									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
										Nigeris
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.299.00</span>
										<del>Rs.539.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Nigeris" />
												<input type="hidden" name="amount" value="299.00" />
												<input type="hidden" name="discount_amount" value="2.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/a3.jpg" width="37%" height="200px"></img><br><br>
									<div class="men-cart-pro">
										<h6 style="font-size:15px;">
										scream “red” or “yellow” <br>good rule of thumb</h6>
									</div>
									<span class="product-new-top">New</span>

								</div>
								<div class="item-info-product ">
									<h4>
								Sunset
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.679.00</span>
										<del>Rs.990.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Sunset />
												<input type="hidden" name="amount" value="679.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>	</div>
							</div>	</div>
							</td><td>
							<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/a4.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">visual artist <br>created for entertainment, political commentary, or advertising.</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>Cartoon
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.423.00/-</span>
										<del>$519.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Cartoon" />
												<input type="hidden" name="amount" value="423.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr><tr><td>
						<div class="col-xs-4 product-men">
							<div class="men-pro-item simpleCart_shelfItem">
								<div class="men-thumb-item">
									<img src="pic/a5.jpg" width="37%" height="200px"></img><br><br>
									<h6 style="font-size:15px;">durable plain-woven fabric <br>made of cotton or linen</h6>
									<span class="product-new-top">New</span>
								</div>
								<div class="item-info-product ">
									<h4>Canvas
									</h4>
									<div class="info-product-price">
										<span class="item_price">Rs.291.00/-</span>
										<del>$390.00</del>
									</div>
									<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
										<form action="#" method="post">
											<fieldset>
												<input type="hidden" name="cmd" value="_cart" />
												<input type="hidden" name="add" value="1" />
												<input type="hidden" name="business" value=" " />
												<input type="hidden" name="item_name" value="Canvas" />
												<input type="hidden" name="amount" value="291.00" />
												<input type="hidden" name="discount_amount" value="1.00" />
												<input type="hidden" name="currency_code" value="USD" />
												<input type="hidden" name="return" value=" " />
												<input type="hidden" name="cancel_return" value=" " />
												<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
											</fieldset>
										</form>
									</div>

								</div>
							</div>
						</div>
						</td></tr></table>
	<!-- PAINTING COMPLETED-->		
	</div>
	<div class="featured-section" id="projects">
		<div class="container">
			<!-- tittle heading -->
			<h3 class="tittle-w3l">Special Offers
				<span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
			</h3>
			<!-- //tittle heading -->
			<div class="content-bottom-in">
				<ul id="flexiselDemo1">
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
								
									<img src="pic/q2.jpg" width="70%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									Ceiling
								</h4>
								<div class="w3l-pricehkj">
									<h6>$2990.00</h6>
									<p>Save $540.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="Ceiling />
											<input type="hidden" name="amount" value="2990.00" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="USD" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
																	<img src="pic/q1.jpg" width="70%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									Recessed [PACK OF 2]						</h4>
								<div class="w3l-pricehkj">
									<h6>$499.00</h6>
									<p>Save $250.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="Recessed [PACK OF 2]" />
											<input type="hidden" name="amount" value="499.00" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="USD" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
								
									<img src="pic/a6.jpeg" width="70%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									Scenary WALLPAPER
								</h4>
								<div class="w3l-pricehkj">
									<h6>$269.00</h6>
									<p>Save $320.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="Scenary WALLPAPER" />
											<input type="hidden" name="amount" value="269.00" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="USD" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
								
									<img src="pic/a7.jpg" width="70%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									DIY PAINTING
								</h4>
								<div class="w3l-pricehkj">
									<h6>$487.00</h6>
									<p>Save $130.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="DIY PAINTING" />
											<input type="hidden" name="amount" value="487.00" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="USD" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
								
									<img src="pic/p7.jpg" width="70%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									Restaurant WALLPAPER								</h4>
								<div class="w3l-pricehkj">
									<h6>$160.00</h6>
									<p>Save $60.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="Restaurant WALLPAPER" />
											<input type="hidden" name="amount" value="160.00" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="USD" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
								
									<img src="pic/p6.jpg" width="50%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									Galaxy WALLPAPER						</h4>
								<div class="w3l-pricehkj">
									<h6>$151.60</h6>
									<p>Save $30.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="Galaxy WALLPAPER" />
											<input type="hidden" name="amount" value="151.60" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="USD" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
								
										<img src="pic/ta6.jpg" width="70%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									Polyester Recycled Carpet Fiber
								</h4>
								<div class="w3l-pricehkj">
									<h6>$2180.00</h6>
									<p>Save $430.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="Polyester Recycled Carpet Fiber" />
											<input type="hidden" name="amount" value="2180.00" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="RS" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="w3l-specilamk">
							<div class="speioffer-agile">
								
									<img src="pic/ta7.jpg" width="70%" height="200px"></img>
								
							</div>
							<div class="product-name-w3l">
								<h4>
									Wool
								</h4>
								<div class="w3l-pricehkj">
									<h6>$2153.00</h6>
									<p>Save $240.00</p>
								</div>
								<div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
									<form action="#" method="post">
										<fieldset>
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="add" value="1" />
											<input type="hidden" name="business" value=" " />
											<input type="hidden" name="item_name" value="Wool" />
											<input type="hidden" name="amount" value="2153.00" />
											<input type="hidden" name="discount_amount" value="1.00" />
											<input type="hidden" name="currency_code" value="USD" />
											<input type="hidden" name="return" value=" " />
											<input type="hidden" name="cancel_return" value=" " />
											<input type="submit" class="single" name="submit" value="Add to cart" class="button" />
										</fieldset>
									</form>
								</div>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- //special offers -->

	
	<!-- copyright -->
	

			<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>About Us</h4>
								<p>
								 The longer I live, the more beautiful life becomes. If you foolishly ignore beauty, you will soon find yourself without it. Your life will be impoverished. But if you invest in beauty, it will remain with you all the days of your life.
								</p>
							</div>
						</div>
						<div class="col-lg-4  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Contact Us</h4>
								<p>
								+777 000 22299
									</p>
								<p class="number">
									012-6532-568-9746 <br>
									012-6532-569-9748
								</p>
							</div>
						</div>						
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4>Newsletter</h4>
								<p>You can trust us. we only send  offers, not a single spam.If you want a golden rule that will fit everything, this is it: Have nothing in your houses that you do not know to be useful or believe to be beautiful.</p>
								
							</div>
						</div>						
					</div>
					<div class="footer-bottom row">
						<p class="footer-text m-0 col-lg-6 col-md-12">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.
						</p>
						
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->
	<!-- //copyright -->

	<!-- js-files -->
	<!-- jquery -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- //jquery -->

	<!-- popup modal (for signin & signup)-->
	<script src="js/jquery.magnific-popup.js"></script>
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
	<!-- Large modal -->
	<!-- <script>
		$('#').modal('show');
	</script> -->
	<!-- //popup modal (for signin & signup)-->

	<!-- cart-js -->
	<script src="js/minicart.js"></script>
	<script>
		paypalm.minicartk.render(); //use only unique class names other than paypal1.minicart1.Also Replace same class name in css and minicart.min.js

		paypalm.minicartk.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
				
			}
			if (total < 1) {
				alert('The minimum order quantity is 1. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
			else
			{
			window.open("payment.php");
			}
		});
	</script>
	<!-- //cart-js -->

	<!-- price range (top products) -->
	<script src="js/jquery-ui.js"></script>
	<script>
		//<![CDATA[ 
		$(window).load(function () {
			$("#slider-range").slider({
				range: true,
				min: 0,
				max: 9000,
				values: [50, 6000],
				slide: function (event, ui) {
					$("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
				}
			});
			$("#amount").val("Rs." + $("#slider-range").slider("values", 0) + " - Rs." + $("#slider-range").slider("values", 1));

		}); //]]>
	</script>
	<!-- //price range (top products) -->

	<!-- flexisel (for special offers) -->
	<script src="js/jquery.flexisel.js"></script>
	<script>
		$(window).load(function () {
			$("#flexiselDemo1").flexisel({
				visibleItems: 3,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,
				pauseOnHover: true,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: {
					portrait: {
						changePoint: 480,
						visibleItems: 1
					},
					landscape: {
						changePoint: 640,
						visibleItems: 2
					},
					tablet: {
						changePoint: 768,
						visibleItems: 2
					}
				}
			});

		});
	</script>
	<!-- //flexisel (for special offers) -->

	<!-- password-script -->
	<script>
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}

		function validatePassword() {
			var pass2 = document.getElementById("password2").value;
			var pass1 = document.getElementById("password1").value;
			if (pass1 != pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');
			//empty string means no validation error
		}
	</script>
	<!-- //password-script -->

	<!-- smoothscroll -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smoothscroll -->

	<!-- start-smooth-scrolling -->
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->

	<!-- smooth-scrolling-of-move-up -->
	<script>
		$(document).ready(function () {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->

	<!-- for bootstrap working -->
	<script src="js/bootstrap1.js"></script>
	<!-- //for bootstrap working -->
	<!-- //js-files -->

</body>

</html>