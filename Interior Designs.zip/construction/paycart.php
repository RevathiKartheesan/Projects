<?php

$type = $_POST["typ"];
$no= $_POST["no"];
$cvv = $_POST["cvv"];
$name = $_POST["name"];
$date = $_POST["da"];

$conn=mysqli_connect("localhost","root");
mysqli_select_db($conn,"looklet");
if ($mysqli->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$select = "insert into paycart(name,no,cvv,type,date)values('".$name."','".$no."','".$cvv."','".$type."','".$date."')";
//echo $select."2";
$sql=mysqli_query($conn,$select);
echo mysqli_error($conn);
echo "inserted successfully";
mysqli_close($conn);
header('location:index.php')
?>
