<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="codepixer">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Plans</title>
		<script>
		function validate()
		{
		x=document.forms
		name=x.name.value
		paas=x.pass.value
		m=0
		if(name== "" && paas=="")
		{
		m=1
		alert("Invalid User Name or Password")
		}
		if(m==0)
		{
		alert("Login Success")
		}
		}
</script>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">	
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>

			  <header id="header" id="home">
			    <div class="container">
			    	<div class="row header-top align-items-center">
			    		<div class="col-lg-4 col-sm-4 menu-top-left">
			    			<img src="pic/l2.jpg" width="15%" height="15%"></img>
			    			<a class="tel" href="mailto:smartlooklet@gmail.com">smartlooklet@gmail.com</a>
			    		</div>
			    		<div class="col-lg-4 menu-top-middle justify-content-center d-flex">
							<a href="index.html">
								<h1>SMART LOOKLET</h1>	
							</a>			    			
			    		</div>
			    		<div class="col-lg-4 col-sm-4 menu-top-right">
			    			<a class="tel" href="tel:+777 000 22299">+777 000 22299</a>
							
      
			    			<img src="pic/l1.jpg" width="15%" height="15%"></img>
							
			    		</div>
			    	</div>
			    </div>	
			    	<hr>
			    <div class="container">	
			    	<div class="row align-items-center justify-content-center d-flex">
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li><a href="index.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
						  <li><a href="project.php">Project</a></li>
				          <li><a href="cart.php">Order</a></li>
				          <li><a href="contact.php">Contact</a></li>
						  <li class="menu-active"><a href="admin.php">Admin</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								User Details
							</h1>	
							
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

<body>

<div class="container"><br>
  <center><h1>User Shopping Details</h1></center>
  <br><br><table class="table table-bordered">
    <thead>
      <tr>
        <th>User Name</th>
        <th>Email Id</th>
        <th>Phone Number</th>
         <th>Address</th>
		 <th>Plan</th>
         <th>Amount Purchased</th>
		 <th>Feedback</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <?php
        $servername ="localhost";
  //create connection
  $con = new mysqli($servername,"root","","looklet");
  if($con->connect_error)
  {
    die("connection failed:".$con->connect_error);
  }

  $result = mysqli_query($con,"SELECT * FROM registration");

  while($row = mysqli_fetch_array($result)){
     echo "<tr>";
echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['email'] . "</td>";
echo "<td>" . $row['phone'] . "</td>";
echo "<td>" . $row['paddress'] . "</td>";
echo "<td>" . $row['Plan'] . "</td>";
echo "<td>" . $row['amount'] . "</td>";
echo "<td>" . $row['Feedback'] . "</td>";
echo "</tr>";
      }?>
      
    </tbody>
  </table>
</div>

</body>

</html>
