<?php
if(isset($_GET['sub']){
    echo $_GET['sub'];
}
?>