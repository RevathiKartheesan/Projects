<?php 
	session_start();
	$mess=$_POST['message'];
	$email=$_SESSION['name'];
	if($_SESSION['name']!="")
	{
		$conn=mysqli_connect("localhost","root");
mysqli_select_db($conn,"looklet");
if ($conn->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$check="UPDATE `registration` set `Feedback`='$mess' where `email`='$email' ";
$selection = mysqli_query( $conn, $check );
header("location:index.php");
	}
	
?>